
-----DATA PREPERATION AND UNDERSTANDING-----

--Q1

select 
'Customer' as [Table Name],count(*) as [No. of Rows]
from Customer

union all

select 
'Transactions', count(*)
from Transactions

union all

select 
'prod_cat_info' , count(*)
from prod_cat_info


--Q2

select
count(total_amt) as return_transactions
from Transactions
where total_amt < 0
 

--Q3

select 
convert(date,tran_date,105) as tran_date2
from Transactions

union all

select convert(date,DOB,105) 
from Customer


--Q4

select
DATEDIFF(day,min(tran_date),max(tran_date)) as [days],
DATEDIFF(month,min(tran_date),max(tran_date)) as [months],
DATEDIFF(year,min(tran_date),max(tran_date)) as [years]
from Transactions


--Q5

select
prod_subcat,prod_cat
from prod_cat_info
where prod_subcat = 'DIY'


-----DATA ANALYSIS-----

--Q1

select top 1
Store_type,count(Store_type) as [count]
from Transactions
group by Store_type
order by count(Store_type) desc


--Q2

select 
'Male' as Gender,count(gender) as cust_count
from Customer
where gender = 'M'

union all

select 
'Female',count(gender) 
from Customer
where gender = 'F'


--Q3

select top 1
city_code,
count(customer_id) as [max count]
from Customer
group by city_code
order by [max count] desc


--Q4

select
count(prod_subcat) as Books_subcat_count
from prod_cat_info
where prod_cat = 'Books'


--Q5

select top 1 Qty
from Transactions
order by Qty desc


--Q6

select
sum(total_amt) as total_revenue
from prod_cat_info as B
full outer join Transactions as C
on B.prod_cat_code = C.prod_cat_code
				and
   B.prod_sub_cat_code = C.prod_subcat_code
where prod_cat in ('Electronics' , 'Books')


--Q7

select
count(customer_Id) as [record count]
from (
		select
		customer_Id
		from Customer as A
		full outer join Transactions as C
		on A.customer_Id = C.cust_id
		where total_amt > 0 
		group by customer_Id
		having count(transaction_id) >10
	  ) as X


--Q8

select
sum(total_amt) as total_revenue
from prod_cat_info as B
right join Transactions as C
on B.prod_cat_code = C.prod_cat_code
				and
   B.prod_sub_cat_code = C.prod_subcat_code
where prod_cat in ('Electronics' , 'Clothing') and Store_type = 'Flagship store'


--Q9

select 
prod_subcat,sum(total_amt) as total_revenue
from Customer as A
right join (
		  	select 
			cust_id,prod_cat,prod_subcat,total_amt
			from prod_cat_info as B
			right join Transactions as C
			on B.prod_cat_code = C.prod_cat_code
							and
			   B.prod_sub_cat_code = C.prod_subcat_code
		  ) as X
on A.customer_Id = X.cust_id
where Gender = 'M' and prod_cat = 'Electronics'
group by prod_subcat


--Q10

select top 5
X.prod_subcat,[percent sales],[percent return]
from   (
	    select
		prod_subcat,
		sum(total_amt)*100/sum(sum(total_amt)) over() as [percent sales]
		from prod_cat_info as B
		right join Transactions as C
		on B.prod_sub_cat_code = C.prod_subcat_code
		where Qty > 0
		group by prod_subcat
		) as X
left join		
		(
		select
		prod_subcat,
		sum(total_amt)*100/sum(sum(total_amt)) over() as [percent return]
		from prod_cat_info as B
		right join Transactions as C
		on B.prod_sub_cat_code = C.prod_subcat_code
		where Qty < 0
		group by prod_subcat
		) as Y
on X.prod_subcat = Y.prod_subcat
order by [percent sales] desc


--Q11

select
SUM(total_amt) as [net total revenue]
from Customer as A
right join Transactions as C
on A.customer_Id = C.cust_id
where DATEDIFF(year,DOB,GETDATE()) > 25 
	and DATEDIFF(year,DOB,GETDATE()) < 35 
and DATEDIFF(day,tran_date,(select max(tran_date) from transactions)) <= 30


--Q12

select top 1
prod_cat,sum(total_amt) as max_return
from prod_cat_info as B
right join Transactions as C
on B.prod_cat_code = C.prod_cat_code
				and
   B.prod_sub_cat_code = C.prod_subcat_code
where total_amt < 0
			and
datediff(month,tran_date,(select max(tran_date) from transactions)) <= 3
group by prod_cat
order by max_return 
		

--Q13

select top 1
Store_type,sum(convert(int,Qty)) as tot_qty,SUM(total_amt)as tot_amt  
from prod_cat_info as B
full outer join Transactions as C
on B.prod_cat_code = C.prod_cat_code
				and
   B.prod_sub_cat_code = C.prod_subcat_code
where CONVERT(int,Qty) > 0
group by Store_type
order by tot_qty desc


--Q14

select
prod_cat
from   (
		select
		prod_cat,AVG(total_amt) as overall_avg
		from prod_cat_info as B
		right join Transactions as C
		on B.prod_cat_code = C.prod_cat_code
						and
		   B.prod_sub_cat_code = C.prod_subcat_code
		group by prod_cat
		) as X
where overall_avg > (select AVG(total_amt) from Transactions)


--Q15

select 
Y.prod_cat,prod_subcat,avg_revenue,total_revenue
from      (
		   select top 5 
		   prod_cat,SUM(Cast(Qty as numeric)) as quantity
		   from Transactions as C
		   left join prod_cat_info as B
		   on C.prod_cat_code = B.prod_cat_code
		                    and
		      C.prod_subcat_code = B.prod_sub_cat_code
		   group by prod_cat
		   order by quantity desc
		   ) as X

inner join(    
		   select 
		   prod_cat, prod_subcat , AVG(total_amt) as avg_revenue, SUM(total_amt) as total_revenue
		   from Transactions as C
		   left join prod_cat_info as B
		   on C.prod_cat_code = B.prod_cat_code
		                    and
		      C.prod_subcat_code = B.prod_sub_cat_code
		   group by prod_cat, prod_subcat
		   ) as Y
on X.prod_cat = Y.prod_cat


------------------------------------------------------------XXXXXXXXXXXXXXXXXXXXXXXXXXXXX---------------------------------------------------------------------------

